from .manager import KnowledgeManager
