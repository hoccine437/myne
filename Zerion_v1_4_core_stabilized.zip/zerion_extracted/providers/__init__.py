"""Official Gemini provider implementation."""
